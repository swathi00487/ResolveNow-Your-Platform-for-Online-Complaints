// Only Node.JS has a process variable that is of [[Class]] process
export default Object.prototype.toString.call(typeof process !== 'undefined' ? process : 0) === '[object process]';
