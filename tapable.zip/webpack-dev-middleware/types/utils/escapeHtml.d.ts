export = escapeHtml;
/**
 * @param {string} string raw HTML
 * @returns {string} escaped HTML
 */
declare function escapeHtml(string: string): string;
